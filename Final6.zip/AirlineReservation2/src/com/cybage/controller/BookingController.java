package com.cybage.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cybage.dao.BookingDao;
import com.cybage.model.Booking;
import com.cybage.model.Flight;


@WebServlet("/ ")
public class BookingController extends HttpServlet {
	private static final long serialVersionUID = 1L;
			private BookingDao bookingDao;
			
			public void init() {
				bookingDao=new BookingDao();
			}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
					throws ServletException, IOException {
				doGet(request, response);
			}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewBookingForm(request, response);
				break;
			case "/insert":
				insertBooking(request, response);
				break;
			case "/delete":
				deleteBooking(request, response);
				break;
			case "/edit":
				showEditBooking(request, response);
				break;
			case "/update":
				updateBooking(request, response);
				break;
			case "/uflist":
				userBookingList(request, response);
				break;
			case "/SearchByEamailId":
				searchBookingByEmailId(request, response);
				break;
			case "/SearchByName":
				searchBookingByFlightName(request, response);
				break;

			case "/SearchByDate":
				searchBookingByDate(request, response);
				break;
			
			default:
				BookingList(request, response);
				break;
			}
		} catch (SQLException ex) {
			throw new ServletException(ex);
		}
	}
	
	private void searchBookingByEmailId(HttpServletRequest request, HttpServletResponse response)throws IOException, ServletException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String emailId = request.getParameter("emailId");
		List<Booking> bookingList = bookingDao.searchBookingByEmailId(emailId);
		request.setAttribute("bookingList", bookingList);
		RequestDispatcher view = request.getRequestDispatcher("BookingSearchView.jsp");
		view.forward(request, response);
		
	}
	
	private void searchBookingByDate(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
		String date = request.getParameter("date");
		List<Booking> bookingList = bookingDao.searchBookingByDate(date);
		request.setAttribute("bookingList", bookingList);
		RequestDispatcher view = request.getRequestDispatcher("BookingSearchView.jsp");
		view.forward(request, response);
	}
	
	private void searchBookingByFlightName(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
		String flightName = request.getParameter("flightName");
		List<Booking>bookingList = bookingDao.searchBookingByFlightName(flightName);
		request.setAttribute("bookingList", bookingList);
		RequestDispatcher view = request.getRequestDispatcher("BookingSearchView.jsp");
		view.forward(request, response);
	}
	
	private void updateBooking(HttpServletRequest request, HttpServletResponse response)throws IOException, SQLException {
		int bookingId = Integer.parseInt(request.getParameter("flightId"));
		int pid=Integer.parseInt(request.getParameter("pid"));
		int flightId=Integer.parseInt(request.getParameter("flightId"));
		String emailId= request.getParameter("flightName");
		String flightName = request.getParameter("flightName");
		String mobileNo = request.getParameter("mobileNumber");
		int noOfPeople = Integer.parseInt(request.getParameter("noOfPeople"));
		String date = request.getParameter("date");
		double price = Double.parseDouble(request.getParameter("price"));
		double finalPrice = Double.parseDouble(request.getParameter("price"))*noOfPeople;
		Booking booking = new Booking(bookingId, pid, flightId, emailId, flightName, mobileNo, noOfPeople, date, price, finalPrice);
		bookingDao.updateBooking(booking);

		response.sendRedirect("list");
		
	}
	private void deleteBooking(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		System.out.println(request.getParameter("bookingId"));
		try {
			int bookingId = Integer.parseInt(request.getParameter("bookingId"));
			bookingDao.deleteBooking(bookingId);

		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("blist");
	}
	private void insertBooking(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int pid= Integer.parseInt(request.getParameter("pid"));
		int flightId= Integer.parseInt(request.getParameter("flightId"));
		String flightName = request.getParameter("flightName");
		String emailId = request.getParameter("emailId");
		String mobileNo = request.getParameter("mobileNo");
		int noOfPeople = Integer.parseInt(request.getParameter("noOfPeople"));
		String date = request.getParameter("date");
		double price = Double.parseDouble(request.getParameter("price"));
		double finalPrice = Double.parseDouble(request.getParameter("price"))*noOfPeople;
		Booking booking = new Booking(pid, flightId, emailId, flightName, mobileNo, noOfPeople, date, price, finalPrice);
		bookingDao.insertBooking(booking);
		
		response.sendRedirect("bList");
	}
	private void showEditBooking(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		Booking existingBooking = bookingDao.selectBooking(bookingId);
		RequestDispatcher dispatcher = request.getRequestDispatcher("BookingUpdateForm.jsp");
		request.setAttribute("booking", existingBooking);
		dispatcher.forward(request, response);

	}
	private void showNewBookingForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("BookingForm.jsp");
		dispatcher.forward(request, response);
	
		
	}
	private void BookingList(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException, ServletException {
		List<Booking> BookingList = bookingDao.selectAllBookings();
		request.setAttribute("BookingList", BookingList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("BookingList.jsp");
		dispatcher.forward(request, response);
	}

	private void userBookingList(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException, ServletException {
		List<Booking> BookingList = BookingDao.selectAllBookings();
		request.setAttribute("BookingList", BookingList);
		RequestDispatcher dispatcher = request.getRequestDispatcher("userBookingHome.jsp");
		dispatcher.forward(request, response);
		
	}

	

}
