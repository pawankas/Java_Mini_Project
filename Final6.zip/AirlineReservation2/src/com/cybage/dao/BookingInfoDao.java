package com.cybage.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cybage.model.BookingInfo;

public class BookingInfoDao {

	 public int bookingInfo(BookingInfo booking) throws ClassNotFoundException {
	        String INSERT_BOOKING_SQL = "INSERT INTO bookinginfo" +
	            "  (bid, emailid, mobileno, noofseats, flightType, category) VALUES " +
	            " (?, ?, ?, ?, ?, ?)";
	        int result = 0;

	        Class.forName("com.mysql.cj.jdbc.Driver");

	        try (Connection connection = DriverManager
	            .getConnection("jdbc:mysql://localhost:3306/flight_reservation?useSSL=false", "root", "root");

	            // Step 2:Create a statement using connection object
	            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_BOOKING_SQL)) {
	            preparedStatement.setInt(1, 0);
	            preparedStatement.setString(2, booking.getEmailid());
	            preparedStatement.setString(3, booking.getMobileno());
	            preparedStatement.setInt(4, booking.getNoofseats());
	            preparedStatement.setString(5, booking.getFlightType());
	            preparedStatement.setString(6, booking.getCategory());
	         
	            
	    

	            System.out.println(preparedStatement);
	            // Step 3: Execute the query or update query
	            result = preparedStatement.executeUpdate();

	        } catch (SQLException e) {
	            // process sql exception
	            printSQLException(e);
	        }
	        return result;
	    }
	 
	    private void printSQLException(SQLException ex) {
	        for (Throwable e: ex) {
	            if (e instanceof SQLException) {
	                e.printStackTrace(System.err);
	                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
	                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
	                System.err.println("Message: " + e.getMessage());
	                Throwable t = ex.getCause();
	                while (t != null) {
	                    System.out.println("Cause: " + t);
	                    t = t.getCause();
	                }
	            }
	        }
	    }
	}


