package com.cybage.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cybage.model.Booking;


public class BookingDao {

	private static String jdbcURL = "jdbc:mysql://localhost:3306/flight_reservation";
	private static String jdbcUsername = "root";
	private static String jdbcPassword = "root";
	private static final String INSERT_BOOKING_SQL = "insert into booking(bookingId,pid,flightId,flightName, emailId, noOfPeople, flightId, date, price,finalPrice) values (?,?,?,?,?,?,?,?,?,?)";
	private static final String SELECT_BOOKING_BY_ID = "select boookingid,pid,flightId,flightName, emailId, noOfPeople, flightId, date, price,finalPrice  from flight where bookingId =?";
	private static final String SELECT_ALL_BOOKINGS = "select * from booking";
	private static final String DELETE_BOOKING_SQL = "delete from booking where bookingId = ?;";
	private static final String UPDATE_BOOKING_SQL = "update booking set pid=?,flightId=?,flightName=?, emailId=?, noOfPeople=?, flightId=?, date=?, price=?,finalPrice=? where bookingId = ?";

	public BookingDao() {
	}

	protected static Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
	

	public static List<Booking> selectAllBookings() {
		
		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Booking> booking = new ArrayList<>();
		
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_BOOKINGS);)  {
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
//				Statement statement;
//				statement = connection.createStatement();
				Booking booking1 = new Booking();
				booking1.setBookingId(rs.getInt("bookingId"));
				booking1.setPid(rs.getInt("pid"));
				booking1.setFlightId(rs.getInt("flightId"));
				booking1.setEmailId(rs.getString("emailId"));
				booking1.setFlightName(rs.getString("flightName"));
				booking1.setMobileNo(rs.getNString("mobileNumber"));
				booking1.setNoOfPeople(rs.getInt("noOfPeolple"));
				booking1.setDate(rs.getString("date"));
				booking1.setPrice(rs.getDouble("price"));
				booking1.setFinalPrice(rs.getDouble("finalPrice"));

				booking.add(booking1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return booking;
	}
	

	public Booking selectBooking(int bookingId) {
		Booking booking = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_BOOKING_BY_ID);) {
			preparedStatement.setInt(1, bookingId);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				
				int pid=rs.getInt("pid");
				int flightId=rs.getInt("flightId");
				String emailId= rs.getString("flightName");
				String flightName = rs.getString("flightName");
				String mobileNo = rs.getString("mobileNo");
				int noOfPeople = rs.getInt("noOfPeople");
				String date = rs.getString("date");
				double price = rs.getDouble("price");
				double finalPrice = rs.getDouble("finalPrice");

				booking =  new Booking(bookingId, pid, flightId, emailId, flightName, mobileNo, noOfPeople, date, price, finalPrice);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return booking;
	}

	

	public boolean updateBooking(Booking booking)throws SQLException {
		boolean rowUpdated;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_BOOKING_SQL);) {
			statement.setInt(1, booking.getBookingId());
			statement.setInt(2, booking.getPid());
			statement.setInt(3, booking.getFlightId());
			statement.setString(4, booking.getEmailId());
			statement.setString(5, booking.getFlightName());
			statement.setString(6, booking.getMobileNo());
			statement.setInt(7, booking.getNoOfPeople());
			statement.setString(8, booking.getDate());
			statement.setDouble(9, booking.getPrice());
			statement.setDouble(10, booking.getFinalPrice());

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	
	public List<Booking> searchBookingByEmailId(String emailId) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
			System.out.println("connected!.....");
			System.out.println(emailId);
			ArrayList al = null;
			ArrayList bookingList = new ArrayList<>();
			String query = "select * from booking";
			if (emailId!= null && !emailId.equals("")) {
				query = "select * from flight where emailId='" + emailId + "' ";
			}
			System.out.println("query " + query);
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				al = new ArrayList();
				al.add(rs.getString(1));
				al.add(rs.getString(2));
				al.add(rs.getString(3));
				al.add(rs.getString(4));
				al.add(rs.getString(5));
				al.add(rs.getString(6));
				al.add(rs.getString(7));
				al.add(rs.getString(8));
				al.add(rs.getString(9));
				al.add(rs.getString(10));
				System.out.println("al :: " + al);
				bookingList.add(al);
			}
			return bookingList;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Booking> searchBookingByDate(String date) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
			System.out.println("connected!.....");
			System.out.println(date);
			ArrayList al = null;
			ArrayList bookingList = new ArrayList<>();
			String query = "select * from booking";
			if (date != null && !date.equals("")) {
				query = "select * from booking where date='" + date + "' ";
			}
			System.out.println("query " + query);
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				al = new ArrayList();
				al.add(rs.getString(1));
				al.add(rs.getString(2));
				al.add(rs.getString(3));
				al.add(rs.getString(4));
				al.add(rs.getString(5));
				al.add(rs.getString(6));
				al.add(rs.getString(7));
				al.add(rs.getString(8));
				al.add(rs.getString(9));
				al.add(rs.getString(10));
				System.out.println("al :: " + al);
				bookingList.add(al);
			}
			return bookingList;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public List<Booking> searchBookingByFlightName(String flightName) {
		Connection conn = null;
		Statement st = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
			System.out.println("connected!.....");
			System.out.println(flightName);
			ArrayList al = null;
			ArrayList bookingList = new ArrayList<>();
			String query = "select * from booking";
			if (flightName != null && !flightName.equals("")) {
				query = "select * from booking where flightName='" + flightName + "' ";
			}
			System.out.println("query " + query);
			st = conn.createStatement();
			ResultSet rs = st.executeQuery(query);

			while (rs.next()) {
				al = new ArrayList();
				al.add(rs.getString(1));
				al.add(rs.getString(2));
				al.add(rs.getString(3));
				al.add(rs.getString(4));
				al.add(rs.getString(5));
				al.add(rs.getString(6));
				al.add(rs.getString(7));
				al.add(rs.getString(8));
				al.add(rs.getString(9));
				al.add(rs.getString(10));
				System.out.println("al :: " + al);
				bookingList.add(al);
			}
			return bookingList;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public boolean deleteBooking(int bookingId)throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_BOOKING_SQL);) {
			statement.setInt(1, bookingId);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
		
	}
	public void insertBooking(Booking booking) throws SQLException {
		System.out.println(INSERT_BOOKING_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_BOOKING_SQL)) {
			preparedStatement.setInt(1, booking.getBookingId());
			preparedStatement.setInt(2, booking.getPid());
			preparedStatement.setInt(3, booking.getFlightId());
			preparedStatement.setString(4, booking.getEmailId());
			preparedStatement.setString(5, booking.getFlightName());
			preparedStatement.setString(6, booking.getMobileNo());
			preparedStatement.setInt(7, booking.getNoOfPeople());
			preparedStatement.setString(8, booking.getDate());
			preparedStatement.setDouble(9, booking.getPrice());
			preparedStatement.setDouble(10, booking.getFinalPrice());

			preparedStatement.executeUpdate();

			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();;
		}
	}

}
