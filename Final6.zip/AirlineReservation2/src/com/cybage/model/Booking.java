package com.cybage.model;

import java.sql.Date;

public class Booking {
	
	private int bookingId;
	private int pid;
	private int flightId;
	private String emailId;
	private String flightName;
	private String mobileNo;
	private int noOfPeople;
	private String date;
	private double price;
	private double finalPrice;
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Booking(int bookingId, int pid, int flightId, String emailId, String flightName, String mobileNo,
			int noOfPeople, String date, double price, double finalPrice) {
		super();
		this.bookingId = bookingId;
		this.pid = pid;
		this.flightId = flightId;
		this.emailId = emailId;
		this.flightName = flightName;
		this.mobileNo = mobileNo;
		this.noOfPeople = noOfPeople;
		this.date = date;
		this.price = price;
		this.finalPrice = finalPrice;
	}

	public Booking(int pid, int flightId, String emailId, String flightName, String mobileNo, int noOfPeople,
			String date, double price, double finalPrice) {
		super();
		this.pid = pid;
		this.flightId = flightId;
		this.emailId = emailId;
		this.flightName = flightName;
		this.mobileNo = mobileNo;
		this.noOfPeople = noOfPeople;
		this.date = date;
		this.price = price;
		this.finalPrice = finalPrice;
	}

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getPid() {
		return pid;
	}

	public void setPid(int pid) {
		this.pid = pid;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public int getNoOfPeople() {
		return noOfPeople;
	}

	public void setNoOfPeople(int noOfPeople) {
		this.noOfPeople = noOfPeople;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getFinalPrice() {
		return finalPrice;
	}

	public void setFinalPrice(double finalPrice) {
		this.finalPrice = finalPrice;
	}

	
}
