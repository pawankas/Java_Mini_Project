package com.cybage.model;

public class BookingInfo {
	private int bid;
	private String emailid;
	private String mobileno;
	private int noofseats;
	private String flightType;
	private String category;
	
	
	
	
	public BookingInfo(int bid, String emailid, String mobileno, int noofseats, String flightType, String category) {
		super();
		this.bid = bid;
		this.emailid = emailid;
		this.mobileno = mobileno;
		this.noofseats = noofseats;
		this.flightType = flightType;
		this.category = category;
	}
	
	
	public BookingInfo() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getBid() {
		return bid;
	}
	public void setBid(int bid) {
		this.bid = bid;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public String getMobileno() {
		return mobileno;
	}
	public BookingInfo(String emailid, String mobileno, int noofseats, String flightType, String category) {
		super();
		this.emailid = emailid;
		this.mobileno = mobileno;
		this.noofseats = noofseats;
		this.flightType = flightType;
		this.category = category;
	}


	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	public int getNoofseats() {
		return noofseats;
	}
	public void setNoofseats(int noofseats) {
		this.noofseats = noofseats;
	}
	public String getFlightType() {
		return flightType;
	}
	public void setFlightType(String flightType) {
		this.flightType = flightType;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "BookingInfo [bid=" + bid + ", emailid=" + emailid + ", mobileno=" + mobileno + ", noofseats="
				+ noofseats + ", flightType=" + flightType + ", category=" + category + "]";
	}


}
